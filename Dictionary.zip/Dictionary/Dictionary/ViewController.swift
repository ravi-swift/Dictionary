//
//  ViewController.swift
//  Dictionary
//
//  Created by Rp on 13/12/18.
//  Copyright © 2018 Ravi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var dictionary = NSMutableDictionary()
    var dict = NSMutableDictionary()
    var dic = ["Sate":"Gujarat","City":"Surat","Country":"India"]
    
  //  var someDict:[Int:String] = [1:"A",2:"B",3:"C",4:"D"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
      //  print(someDict)
        
        dictionary.setValue("City", forKey: "Surat")
        dictionary.setValue("State", forKey: "Gujarat")
        dictionary.setValue("Pin", forKey: "395004")
        dictionary.setValue("country", forKey: "India")
        dictionary.setValuesForKeys(["city":"Abc","A":"B","C":"D",])

     //   dictionary.removeAllObjects()
        dictionary.removeObject(forKey: "surat")
        dictionary.removeObjects(forKeys: ["Abc","A","C"])
        
        dictionary.setObject("1", forKey: "One" as NSCopying)
        
        print(dictionary)
        
//        dict.setValuesForKeys(["Country":"India","State":"Gujarat","City":"Surat","Pin":"395004",])
//
//        print(dict)
        
 //       print(dic)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

